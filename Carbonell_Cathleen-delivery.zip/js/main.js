$(document).ready
	(function() {
    $('weapon').addClass('show') );
});